let ham = document.getElementById("ham");

ham.addEventListener("click",function(){
    let menu = document.getElementById("menu");
   menu.classList.toggle("show");
    });


